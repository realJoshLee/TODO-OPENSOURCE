/* Use the following document down below to configure the MySQL database to work properly with the todo application*/

-- Dumping structure for table webapps.favoritetasks
CREATE TABLE IF NOT EXISTS `favoritetasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `done` tinyint(4) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.

-- Dumping structure for table webapps.feedback
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(50) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.

-- Dumping structure for table webapps.items
CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `done` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COMMENT='Home index page of tasks for Todo,';

-- Data exporting was unselected.

-- Dumping structure for table webapps.personaltasks
CREATE TABLE IF NOT EXISTS `personaltasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `done` tinyint(4) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8mb4 COMMENT='Personal tasks for todo.';

-- Data exporting was unselected.

-- Dumping structure for table webapps.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(256) DEFAULT NULL,
  `donor` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`username`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COMMENT='Users for all web apps.\r\n';

-- Data exporting was unselected.

-- Dumping structure for table webapps.worktasks
CREATE TABLE IF NOT EXISTS `worktasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `done` tinyint(4) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COMMENT='Work page of tasks for Todo,';