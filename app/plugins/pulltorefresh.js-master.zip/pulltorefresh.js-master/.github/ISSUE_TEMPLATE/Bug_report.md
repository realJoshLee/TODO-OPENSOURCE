---
name: Bug report
about: Open a bug report

---

<!-- Please keep and fill the information required within this template. Issues without this template will be closed. -->

# Bug report

<!-- Use StackOverflow for support requests -->
<!-- https://stackoverflow.com/questions/tagged/pulltorefresh.js -->

**Current behavior:**

**Expected behavior:**

**JSFiddle URL for demo with bug:**

**Browsers affected:**
