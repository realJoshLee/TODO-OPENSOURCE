<?php
  error_reporting(0);
  ?>

<?php  
  session_start();
  if(!isset($_SESSION["username"]))  
  {  
    header("location:../index.php?action=login");  
  }
  ?>
  
<?php
  require_once 'init.php';

  $personaltasksQuery = $db->prepare("SELECT id, name, done FROM personaltasks WHERE user = :user");

  $personaltasksQuery->execute([
    'user' => $_SESSION['user_id']
    ]);

  $personaltasks = $personaltasksQuery->rowCount() ? $personaltasksQuery : [];
  ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Home</title>
	
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8">
		<meta name="author" content="Josh Lee - joshlee.pw">
				
		<!--Links to stylesheets-->
		<link rel="shortcut icon" type="image/png" href="assets/images/favicon.png"/>
		<link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="tasks.css">
    <script src="tasks.js"></script>
				
		<!--Font Links-->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
		<!--font-family: 'Raleway', sans-serif; - font-family: 'Montserrat', sans-serif; - font-family: 'Open Sans', sans-serif;-->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>
		<!--Body-->
		<div class="body">
      <!--Settings and task view container-->
      <div class="row">
        <!--Settings and nav-->
        <div id="settings" class="column">
          <!--Folder Selection-->
          <div class="folders">
            <h3 class="title">Folders:</h3>
            <a href="index.php" class="folder-link-button"><p class="folder" id="inbox">&nbsp;&nbsp;<img src="assets/images/inbox-white.png" id="folder-icon" class="inbox-button">&nbsp;Inbox</p></a>
            <a href="#" class="folder-link-button" id="personal-link"><p id="active" class="folder">&nbsp;&nbsp;<img src="assets/images/user-white.png" id="folder-icon" class="personal-button">&nbsp;Personal</p></a>
            <a href="work.php" class="folder-link-button"><p class="folder" id="work">&nbsp;&nbsp;<img src="assets/images/work-white.png" id="folder-icon" class="work-button">&nbsp;Work</p></a>
            
            <br><br>

            <!--Dropdown Icon-->
            <div class="dropdown">
              <!--Icon-->
              <button class="dropbtn"><img src="assets/images/settings-white.png" class="settings-icon"></button>
              <!--Content that is in the dropdown-->
              <div class="dropdown-content">
                <a href="#" class="nav-link"><i><?php echo $_SESSION["username"]; ?></i></a>
                <br>
                <a class="nav-link" href="logout.php">Log Out</a>
                <a class="nav-link" href="account.php">Account</a>
                <a class="nav-link" href="task-history.php">Task History</a>
                <a class="nav-link" href="../../changelog.html">Change Log</a>
                <a class="nav-link" href="feedback/feedback.php" target="_blank">Give Feedback</a>
              </div>
            <style>
              img.settings-icon {
                height: 30px;
                width: 30px;
              }
              .dropbtn {
                background-color: transparent;
                color: #080808;
                font-size: 30px;
                border: none;
                cursor: pointer;
              }

              .dropdown {
                position: relative;
                display: inline-block;
              }

              .dropdown-content {
                display: none;
                position: absolute;
                background-color: #f9f9f9;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
              }

              .dropdown-content a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
              }

              .dropdown-content a:hover {
                background-color: #f1f1f1
              }

              .dropdown:hover .dropdown-content {
                display: block;
              }

              .dropdown:hover .dropbtn {
                opacity: 0.7;
              }

              div#settings {
                width: 15%;

                background-image: url(assets/images/side.grad.2.png);
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                /*background-color: #f5f5f7;*/
                color: #fff;
                -webkit-box-shadow: 0px 0px 5px 0px rgba(147,175,251,1);
                -moz-box-shadow: 0px 0px 5px 0px rgba(147,175,251,1);
                box-shadow: 0px 0px 5px 0px rgba(147,175,251,1);
              }

              a.folder-link-button {
                text-decoration: none;
                color: #fff;
              }

              a.folder-link-button:hover {
                opacity: 0.6;
                transition-duration: 0.3s;
              }

              #active {
                border-left: 2px solid #fff;
              }

              @media screen and (max-width: 597px) {
                div#settings {
                  width: 100%;
                  height: auto;

                  background-image: url(assets/images/side.grad.2.png);
                  background-size: cover;
                  background-position: center;
                  background-repeat: no-repeat;
                }
              }
            </style>
            </div>
          </div>
        </div>
        
        <!--Tasks-->
        <div id="task-lists" class="column">
          <!--Header Title-->
          <h2 class="header">Personal > Tasks:</h2>

          <!--Divider Accent-->
          <hr width="100px" color="#5297ff" align="left">
          <br>

          <!--Where the tasks are listed-->
          <?php if(!empty($personaltasks)): ?>
          <ul class="personaltasks">
            <?php foreach($personaltasks as $item): ?><?php if (!$item['done']):?><li><a href="personal-mark.php?as=done&item=<?php echo $item['id'] ?>" class="done-button"><span class="dot"></span></a>&nbsp;<span class="item<?php echo $item['done'] ? 'done' : '' ?>"><?php echo $item['name']; ?></span></li><?php endif; ?><?php endforeach; ?>
          </ul>
          <?php else: ?>
            <!--What is shown when there aren't any personaltasks in the list-->
            <p>You haven't added any personal tasks. Add some below to get started.</p>
          <?php endif; ?>

          <!--The form where you add a task-->
          <form class="item-add" action="personal-add.php" method="post">
            <input type="text" name="name" placeholder="Type a new item here." class="task" autocomplete="off" required autofocus>
            <br><br>
            <input type="submit" value="Add" class="submit">
          </form>
        </div>
      </div>
      
		</div>

	</body>
</html>